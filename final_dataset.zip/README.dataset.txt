# jh > 2024-12-18 8:14pm
https://universe.roboflow.com/anonymous-man/jh-gsbq2

Provided by a Roboflow user
License: CC BY 4.0

